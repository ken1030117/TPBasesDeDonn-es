//Kenny Saint-Cyr
//Code Perm: SAIK17119305
//Valentin Pigaux
//Code Perm: PIGV74050106
//Script de Procédures
// Cette classe affiche la liste d'articles en stock disponible.

import java.sql.*;

import oracle.jdbc.driver.OracleDriver;


public class ConsulterArticles {

    public static void main(String args[])
            throws SQLException, ClassNotFoundException, java.io.IOException {

        // Charger le pilote JDBC d'Oracle
        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
        // Class.forName ("oracle.jdbc.driver.OracleDriver");

        // Connexion ? une BD
        Connection uneConnection =
//      DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:ora9i", "godin", "oracle");
                DriverManager.getConnection("jdbc:oracle:thin:@zeta2.labunix.uqam.ca:1521:baclab", "ae291054", "yIMnAytg");


        Statement unEnonceSQL = uneConnection.createStatement();

        ResultSet resultatSelect = unEnonceSQL.executeQuery
                ("SELECT numArticle, codeCategorie, numFournisseur, description, prix, quantite, URL\n" +
                        "FROM Article");
        System.out.println("numArticle  ||  codeCategorie   ||  numFournisseur   ||   description  ||   prix  ||   quantite   ||  URL");

        while (resultatSelect.next()) {
            int leNumArticle = resultatSelect.getInt("numArticle");
            int leCodeCategorie = resultatSelect.getInt("codeCategorie");
            int leNumFournisseur = resultatSelect.getInt("numFournisseur");
            String leDescription = resultatSelect.getString("description");
            float lePrix = resultatSelect.getFloat("prix");
            int leQuantite = resultatSelect.getInt("quantite");
            String leURL = resultatSelect.getString("URL");
            System.out.println(leNumArticle + " || " + leCodeCategorie
                    + " || " + leNumFournisseur + " || " + leDescription
                    + " || " + lePrix + " || " + leQuantite + " || " + leURL);
        }


    }

}
