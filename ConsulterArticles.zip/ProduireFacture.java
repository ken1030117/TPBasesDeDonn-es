//Kenny Saint-Cyr
//Code Perm: SAIK17119305
//Valentin Pigaux
//Code Perm: PIGV74050106
//Script de Procédures
// Cette classe affiche la facture selon le nombre de

import oracle.jdbc.driver.OracleDriver;

import java.io.IOException;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ProduireFacture {

    /**
     * Retourne un Statement SQL afin de pouvoir affecter les données SQL.
     *
     * @return un Statement SQL
     * @throws SQLException lorsqu'aucune connection est possible.
     */
    private static Connection FaireConnectionSQL()
            throws SQLException {
        DriverManager.registerDriver(new OracleDriver());

        return DriverManager.getConnection("jdbc:oracle:thin:@zeta2.labunix.uqam.ca:1521:baclab", "ae291054", "yIMnAytg");
    }

    /**
     * Retourne un Statement SQL afin de pouvoir affecter les données SQL.
     *
     * @return un Statement SQL
     * @throws SQLException lorsqu'aucune connection est possible.
     */
    private static Statement FaireEnonceSQL(Connection uneConnection)
            throws SQLException {
        return uneConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    }

    /**
     * Permet de trouver le numéro du client selon la livraison donnée.
     *
     * @param Livraison
     * @return le numéro du client
     * @throws SQLException           lorsqu'aucune connection est possible.
     * @throws ClassNotFoundException
     * @throws java.io.IOException
     */
    private static int trouverLeNumClient(int Livraison)
            throws SQLException, ClassNotFoundException, java.io.IOException {
        int leNumClient = 0;

        ResultSet resultatSelectClient =
                FaireEnonceSQL(FaireConnectionSQL()).executeQuery("SELECT *  FROM Livraison");

        while (resultatSelectClient.next()) {
            if (resultatSelectClient.getInt("numLivraison") == Livraison)
                leNumClient = resultatSelectClient.getInt("numClient");
        }
        return leNumClient;
    }

    /**
     * Recherche les infos du client selon la livraison et affiche les infos.
     *
     * @param Livraison Le numéro de la livraison
     * @throws SQLException lorsqu'aucune connection est possible.
     */
    public static void trouverinfosClient(int Livraison)
            throws SQLException, IOException, ClassNotFoundException {
        int numClient = trouverLeNumClient(Livraison);
        ResultSet resultatSelectClient =
                FaireEnonceSQL(FaireConnectionSQL()).executeQuery("SELECT * \n" +
                        "FROM Client");

        while (resultatSelectClient.next()) {
            if (numClient == resultatSelectClient.getInt("numClient")) {
                String leNom = resultatSelectClient.getString("nom");
                String lePrenom = resultatSelectClient.getString("prenom");
                String leCourriel = resultatSelectClient.getString("courriel");
                String lAddresse = resultatSelectClient.getString("addresse");
                String leTypeClient = resultatSelectClient.getString("typeClient");

                System.out.println("No. Facture: " + Livraison);
                System.out.println("No. Client: " + numClient);
                System.out.println("Prenom: " + lePrenom);
                System.out.println("Nom: " + leNom);
                System.out.println("Courriel: " + leCourriel);
                System.out.println("Addresse: " + lAddresse);
                System.out.println("leTypeClient: " + leTypeClient);
                System.out.println("No. Article || Description || URL || Quantité || Montant Après Escomptes");

            }
        }
    }

    /**
     * Affiche les infos de la livraison, les articles, le prix unitaire et le prix total.
     * @param livraison
     * @param dateLimitePaiement
     * @throws SQLException           lorsqu'aucune connection est possible.
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws ParseException         lorsque la date n'est pas permise.
     */
    public static void imprimerFacture(int livraison, String dateLimitePaiement)
            throws SQLException, IOException,
            ClassNotFoundException, ParseException {
        PreparedStatement insertFacture =
                FaireConnectionSQL().prepareStatement("INSERT INTO Facture VALUES (?,?,?,?,?)");
        float prixTotal = 0;
        int numArticle;
        String laDescription;
        String leURL;
        float lePrix = 0;
        int laQuantite = 0;
        int totalQuantite = 0;
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date laDateLimitePaiement = dateFormat.parse(dateLimitePaiement);

        ResultSet resultatSelectLivraison =
                FaireEnonceSQL(FaireConnectionSQL()).executeQuery("SELECT * \n" +
                "FROM LigneLivraison");
        String Query2 = "SELECT * FROM Article";
        String Query3 = "SELECT * FROM LigneCommande";
        ResultSet resultatSelectArticle =
                FaireEnonceSQL(FaireConnectionSQL()).executeQuery(Query2);

        ResultSet resultatSelectLigneCommande =
                FaireEnonceSQL(FaireConnectionSQL()).executeQuery(Query3);

        while (resultatSelectLivraison.next()) {
            resultatSelectArticle.beforeFirst();
            resultatSelectLigneCommande.beforeFirst();
            if (resultatSelectLivraison.getInt("numLivraison") == livraison) {
                numArticle = resultatSelectLivraison.getInt("numArticle");
                while (resultatSelectArticle.next()) {
                    if (resultatSelectArticle.
                            getInt("numArticle") == numArticle) {
                        laDescription = resultatSelectArticle.
                                getString("description");
                        leURL = resultatSelectArticle.
                                getString("URL");
                        lePrix = resultatSelectArticle.
                                getFloat("prix");
                        while (resultatSelectLigneCommande.next()) {
                            if (resultatSelectLigneCommande.
                                    getInt("numArticle") == numArticle) {
                                laQuantite = resultatSelectLigneCommande.
                                        getInt("quantiteCommande");
                                System.out.println(numArticle + " || " + laDescription + " || " + leURL + " || " + laQuantite + " || " + lePrix);
                                prixTotal = prixTotal + lePrix * laQuantite;
                                totalQuantite = totalQuantite + laQuantite;


                            }
                        }

                    }

                }
            }
        }
        System.out.println("Total: " + prixTotal);
        insererFacture(livraison, trouverLeNumClient(livraison), totalQuantite,
                new java.sql.Date(laDateLimitePaiement.getTime()), prixTotal);
    }



    public static void insererFacture(int livraison, int numClient, int laQuantite,
                                      java.sql.Date laDateLimitePaiement, float lePrix)
            throws SQLException, IOException, ClassNotFoundException {
        PreparedStatement insertFacture =
                FaireConnectionSQL().prepareStatement("INSERT INTO Facture VALUES (?,?,?,?,?)");

        insertFacture.setInt(1, livraison);
        insertFacture.setInt(2, numClient);
        insertFacture.setInt(3, laQuantite);
        insertFacture.setDate(4, laDateLimitePaiement);
        insertFacture.setFloat(5, lePrix);
        insertFacture.execute();

    }

    public static void produireFacture(int Livraison, String dateLimitePaiement)
            throws SQLException, IOException, ClassNotFoundException, ParseException {
        trouverinfosClient(Livraison);
        imprimerFacture(Livraison, dateLimitePaiement);
    }

    public static void main(String args[])
            throws SQLException, ClassNotFoundException, IOException, ParseException {
        produireFacture(1, "06/06/2022");

//


    }

}
